# Data ingestion package — HDFS client, data loading, and validation
