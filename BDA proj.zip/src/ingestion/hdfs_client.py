"""
HDFS Client Module
===================

Production-quality HDFS client wrapping PyArrow's HDFS interface.
Provides all filesystem operations needed by the pipeline:
connect, create directories, upload, download, delete, copy,
move, check existence, and list contents.

Design Decisions:
    - Open/Closed Principle: All storage operations are abstracted
      behind this single class. Swapping storage backends requires
      only replacing this module.
    - All operations include retry logic for transient failures.
    - Every operation is logged for observability.
    - Connection is established lazily on first use and cached.
"""

import os
import time
from typing import Any, Dict, List, Optional

from src.logging.logger_factory import LoggerFactory
from src.utils.hdfs_utils import hdfs_path_join


class HDFSConnectionError(Exception):
    """Raised when HDFS connection cannot be established."""
    pass


class HDFSOperationError(Exception):
    """Raised when an HDFS operation fails after all retries."""
    pass


class HDFSClient:
    """
    Reusable HDFS client for distributed file system operations.

    Wraps PyArrow's HadoopFileSystem to provide a clean interface
    with retry logic, logging, and error handling.

    Attributes:
        _namenode_uri: HDFS NameNode URI (e.g., hdfs://localhost:9000).
        _base_path: Base directory for all project data in HDFS.
        _replication_factor: HDFS replication factor.
        _max_retries: Maximum number of retry attempts.
        _retry_delay: Seconds between retry attempts.
        _fs: PyArrow HadoopFileSystem instance (lazy-initialized).
    """

    def __init__(self, hadoop_config: Dict[str, Any]) -> None:
        """
        Initialize HDFSClient from Hadoop configuration.

        Args:
            hadoop_config: The 'hadoop' section from the merged config.
                           Expected structure:
                           {
                               'hdfs': {
                                   'namenode_uri': 'hdfs://localhost:9000',
                                   'base_path': '/user/energy_prediction',
                                   'paths': {...},
                                   'replication_factor': 1,
                                   'max_retries': 3,
                                   'retry_delay': 5
                               }
                           }
        """
        self._logger = LoggerFactory.get_logger(self.__class__.__name__)

        hdfs_cfg = hadoop_config.get("hdfs", {})
        self._namenode_uri: str = hdfs_cfg.get(
            "namenode_uri", "hdfs://localhost:9000"
        )
        self._base_path: str = hdfs_cfg.get(
            "base_path", "/user/energy_prediction"
        )
        self._replication_factor: int = hdfs_cfg.get("replication_factor", 1)
        self._connection_timeout: int = hdfs_cfg.get("connection_timeout", 30)
        self._max_retries: int = hdfs_cfg.get("max_retries", 3)
        self._retry_delay: int = hdfs_cfg.get("retry_delay", 5)
        self._hdfs_paths: Dict[str, str] = hdfs_cfg.get("paths", {})

        self._fs: Optional[Any] = None  # Lazy-initialized PyArrow filesystem

        self._logger.info(
            "HDFSClient initialized: namenode=%s, base_path=%s",
            self._namenode_uri,
            self._base_path,
        )

    # ----------------------------------------------------------------
    # Connection Management
    # ----------------------------------------------------------------

    def connect(self) -> None:
        """
        Establish connection to HDFS.

        Uses PyArrow's HadoopFileSystem. Retries on transient failures.

        Raises:
            HDFSConnectionError: If connection fails after all retries.
        """
        if self._fs is not None:
            self._logger.debug("HDFS connection already established.")
            return

        import pyarrow

        for attempt in range(1, self._max_retries + 1):
            try:
                self._logger.info(
                    "Connecting to HDFS at %s (attempt %d/%d)...",
                    self._namenode_uri,
                    attempt,
                    self._max_retries,
                )

                # Parse host and port from URI
                host, port = self._parse_namenode_uri()

                self._fs = pyarrow.hdfs.connect(
                    host=host,
                    port=port,
                )

                self._logger.info(
                    "Successfully connected to HDFS at %s:%d", host, port
                )
                return

            except Exception as e:
                self._logger.warning(
                    "HDFS connection attempt %d/%d failed: %s",
                    attempt,
                    self._max_retries,
                    str(e),
                )
                if attempt < self._max_retries:
                    self._logger.info(
                        "Retrying in %d seconds...", self._retry_delay
                    )
                    time.sleep(self._retry_delay)

        error_msg = (
            f"Failed to connect to HDFS at {self._namenode_uri} "
            f"after {self._max_retries} attempts."
        )
        self._logger.error(error_msg)
        raise HDFSConnectionError(error_msg)

    def disconnect(self) -> None:
        """Close the HDFS connection if open."""
        if self._fs is not None:
            try:
                self._fs.close()
                self._logger.info("HDFS connection closed.")
            except Exception as e:
                self._logger.warning(
                    "Error closing HDFS connection: %s", str(e)
                )
            finally:
                self._fs = None

    def _ensure_connected(self) -> None:
        """Ensure HDFS connection is active; connect if not."""
        if self._fs is None:
            self.connect()

    def _parse_namenode_uri(self) -> tuple:
        """
        Parse host and port from the NameNode URI.

        Returns:
            Tuple of (host: str, port: int).
        """
        uri = self._namenode_uri
        # Remove hdfs:// prefix
        if uri.startswith("hdfs://"):
            uri = uri[7:]
        # Split host:port
        if ":" in uri:
            host, port_str = uri.rsplit(":", 1)
            port = int(port_str)
        else:
            host = uri
            port = 9000  # Default HDFS port
        return host, port

    # ----------------------------------------------------------------
    # Directory Operations
    # ----------------------------------------------------------------

    def create_directory(self, hdfs_path: str) -> bool:
        """
        Create a directory in HDFS (recursive, like mkdir -p).

        Args:
            hdfs_path: HDFS directory path to create.

        Returns:
            True if directory was created or already exists.

        Raises:
            HDFSOperationError: If directory creation fails.
        """
        self._ensure_connected()
        return self._retry_operation(
            operation_name=f"create_directory({hdfs_path})",
            func=self._do_create_directory,
            hdfs_path=hdfs_path,
        )

    def _do_create_directory(self, hdfs_path: str) -> bool:
        """Internal: create directory in HDFS."""
        if self.exists(hdfs_path):
            self._logger.debug(
                "HDFS directory already exists: %s", hdfs_path
            )
            return True

        self._fs.mkdir(hdfs_path)
        self._logger.info("Created HDFS directory: %s", hdfs_path)
        return True

    def list_directory(self, hdfs_path: str) -> List[str]:
        """
        List contents of an HDFS directory.

        Args:
            hdfs_path: HDFS directory path to list.

        Returns:
            List of file/directory names in the specified path.

        Raises:
            HDFSOperationError: If listing fails.
        """
        self._ensure_connected()
        return self._retry_operation(
            operation_name=f"list_directory({hdfs_path})",
            func=self._do_list_directory,
            hdfs_path=hdfs_path,
        )

    def _do_list_directory(self, hdfs_path: str) -> List[str]:
        """Internal: list HDFS directory contents."""
        contents = self._fs.ls(hdfs_path)
        self._logger.debug(
            "Listed HDFS directory %s: %d items", hdfs_path, len(contents)
        )
        return contents

    # ----------------------------------------------------------------
    # File Operations
    # ----------------------------------------------------------------

    def upload_file(
        self, local_path: str, hdfs_path: str, overwrite: bool = False
    ) -> bool:
        """
        Upload a local file to HDFS.

        Args:
            local_path: Absolute path to the local file.
            hdfs_path: Destination path in HDFS.
            overwrite: If True, overwrite existing file.

        Returns:
            True if upload succeeded.

        Raises:
            FileNotFoundError: If local file does not exist.
            HDFSOperationError: If upload fails after retries.
        """
        if not os.path.isfile(local_path):
            raise FileNotFoundError(
                f"Local file not found: {local_path}"
            )

        if not overwrite and self.exists(hdfs_path):
            self._logger.info(
                "HDFS file already exists (skipping upload): %s", hdfs_path
            )
            return True

        self._ensure_connected()
        return self._retry_operation(
            operation_name=f"upload_file({local_path} → {hdfs_path})",
            func=self._do_upload_file,
            local_path=local_path,
            hdfs_path=hdfs_path,
        )

    def _do_upload_file(self, local_path: str, hdfs_path: str) -> bool:
        """Internal: upload file to HDFS."""
        # Ensure parent directory exists
        parent_dir = os.path.dirname(hdfs_path)
        if parent_dir and parent_dir != "/":
            self._do_create_directory(parent_dir)

        file_size_mb = os.path.getsize(local_path) / (1024 * 1024)
        self._logger.info(
            "Uploading file to HDFS: %s → %s (%.2f MB)",
            local_path,
            hdfs_path,
            file_size_mb,
        )

        with open(local_path, "rb") as local_file:
            with self._fs.open(hdfs_path, "wb") as hdfs_file:
                # Read and write in chunks for large files
                chunk_size = 64 * 1024 * 1024  # 64 MB chunks
                while True:
                    chunk = local_file.read(chunk_size)
                    if not chunk:
                        break
                    hdfs_file.write(chunk)

        self._logger.info(
            "Successfully uploaded to HDFS: %s (%.2f MB)",
            hdfs_path,
            file_size_mb,
        )
        return True

    def download_file(self, hdfs_path: str, local_path: str) -> bool:
        """
        Download a file from HDFS to local filesystem.

        Args:
            hdfs_path: Source path in HDFS.
            local_path: Destination path on local filesystem.

        Returns:
            True if download succeeded.

        Raises:
            HDFSOperationError: If the file does not exist or download fails.
        """
        self._ensure_connected()
        return self._retry_operation(
            operation_name=f"download_file({hdfs_path} → {local_path})",
            func=self._do_download_file,
            hdfs_path=hdfs_path,
            local_path=local_path,
        )

    def _do_download_file(self, hdfs_path: str, local_path: str) -> bool:
        """Internal: download file from HDFS."""
        if not self.exists(hdfs_path):
            raise HDFSOperationError(
                f"HDFS file does not exist: {hdfs_path}"
            )

        # Ensure local parent directory exists
        local_dir = os.path.dirname(local_path)
        if local_dir:
            os.makedirs(local_dir, exist_ok=True)

        self._logger.info(
            "Downloading from HDFS: %s → %s", hdfs_path, local_path
        )

        with self._fs.open(hdfs_path, "rb") as hdfs_file:
            with open(local_path, "wb") as local_file:
                chunk_size = 64 * 1024 * 1024  # 64 MB chunks
                while True:
                    chunk = hdfs_file.read(chunk_size)
                    if not chunk:
                        break
                    local_file.write(chunk)

        self._logger.info("Successfully downloaded from HDFS: %s", hdfs_path)
        return True

    def delete(self, hdfs_path: str, recursive: bool = False) -> bool:
        """
        Delete a file or directory from HDFS.

        Args:
            hdfs_path: Path in HDFS to delete.
            recursive: If True, delete directory contents recursively.

        Returns:
            True if deletion succeeded.

        Raises:
            HDFSOperationError: If deletion fails.
        """
        self._ensure_connected()
        return self._retry_operation(
            operation_name=f"delete({hdfs_path}, recursive={recursive})",
            func=self._do_delete,
            hdfs_path=hdfs_path,
            recursive=recursive,
        )

    def _do_delete(self, hdfs_path: str, recursive: bool = False) -> bool:
        """Internal: delete file or directory from HDFS."""
        if not self.exists(hdfs_path):
            self._logger.warning(
                "HDFS path does not exist (nothing to delete): %s", hdfs_path
            )
            return True

        self._fs.delete(hdfs_path, recursive=recursive)
        self._logger.info(
            "Deleted from HDFS: %s (recursive=%s)", hdfs_path, recursive
        )
        return True

    def exists(self, hdfs_path: str) -> bool:
        """
        Check if a path exists in HDFS.

        Args:
            hdfs_path: Path in HDFS to check.

        Returns:
            True if the path exists.
        """
        self._ensure_connected()
        try:
            info = self._fs.info(hdfs_path)
            return info is not None
        except (FileNotFoundError, OSError, Exception):
            return False

    def copy_file(
        self, source_path: str, dest_path: str, overwrite: bool = False
    ) -> bool:
        """
        Copy a file within HDFS.

        Since PyArrow HDFS does not support direct copy, this reads the
        source and writes to the destination.

        Args:
            source_path: Source HDFS path.
            dest_path: Destination HDFS path.
            overwrite: If True, overwrite existing destination.

        Returns:
            True if copy succeeded.

        Raises:
            HDFSOperationError: If copy fails.
        """
        self._ensure_connected()
        return self._retry_operation(
            operation_name=f"copy_file({source_path} → {dest_path})",
            func=self._do_copy_file,
            source_path=source_path,
            dest_path=dest_path,
            overwrite=overwrite,
        )

    def _do_copy_file(
        self, source_path: str, dest_path: str, overwrite: bool = False
    ) -> bool:
        """Internal: copy file within HDFS."""
        if not self.exists(source_path):
            raise HDFSOperationError(
                f"Source path does not exist: {source_path}"
            )

        if not overwrite and self.exists(dest_path):
            self._logger.info(
                "Destination already exists (skipping copy): %s", dest_path
            )
            return True

        # Ensure destination parent directory exists
        parent_dir = os.path.dirname(dest_path)
        if parent_dir and parent_dir != "/":
            self._do_create_directory(parent_dir)

        self._logger.info(
            "Copying within HDFS: %s → %s", source_path, dest_path
        )

        with self._fs.open(source_path, "rb") as src:
            with self._fs.open(dest_path, "wb") as dst:
                chunk_size = 64 * 1024 * 1024
                while True:
                    chunk = src.read(chunk_size)
                    if not chunk:
                        break
                    dst.write(chunk)

        self._logger.info("Successfully copied: %s → %s", source_path, dest_path)
        return True

    def move_file(self, source_path: str, dest_path: str) -> bool:
        """
        Move (rename) a file or directory within HDFS.

        Args:
            source_path: Source HDFS path.
            dest_path: Destination HDFS path.

        Returns:
            True if move succeeded.

        Raises:
            HDFSOperationError: If move fails.
        """
        self._ensure_connected()
        return self._retry_operation(
            operation_name=f"move_file({source_path} → {dest_path})",
            func=self._do_move_file,
            source_path=source_path,
            dest_path=dest_path,
        )

    def _do_move_file(self, source_path: str, dest_path: str) -> bool:
        """Internal: move file within HDFS."""
        if not self.exists(source_path):
            raise HDFSOperationError(
                f"Source path does not exist: {source_path}"
            )

        # Ensure destination parent directory exists
        parent_dir = os.path.dirname(dest_path)
        if parent_dir and parent_dir != "/":
            self._do_create_directory(parent_dir)

        self._logger.info(
            "Moving within HDFS: %s → %s", source_path, dest_path
        )
        self._fs.rename(source_path, dest_path)
        self._logger.info("Successfully moved: %s → %s", source_path, dest_path)
        return True

    def get_file_info(self, hdfs_path: str) -> Optional[Dict[str, Any]]:
        """
        Get metadata for a file or directory in HDFS.

        Args:
            hdfs_path: Path in HDFS.

        Returns:
            Dictionary with file metadata (size, type, etc.) or None.
        """
        self._ensure_connected()
        try:
            info = self._fs.info(hdfs_path)
            self._logger.debug("File info for %s: %s", hdfs_path, info)
            return info
        except Exception:
            return None

    # ----------------------------------------------------------------
    # Path Helpers
    # ----------------------------------------------------------------

    def get_hdfs_path(self, path_key: str) -> str:
        """
        Get a configured HDFS path by its key name.

        Args:
            path_key: Key from hadoop_config.yaml paths section
                      (e.g., 'raw_data', 'processed_data').

        Returns:
            The full HDFS path.

        Raises:
            KeyError: If path_key is not found in configuration.
        """
        if path_key not in self._hdfs_paths:
            raise KeyError(
                f"HDFS path key '{path_key}' not found in configuration. "
                f"Available keys: {list(self._hdfs_paths.keys())}"
            )
        return self._hdfs_paths[path_key]

    @property
    def base_path(self) -> str:
        """Return the HDFS base path."""
        return self._base_path

    @property
    def namenode_uri(self) -> str:
        """Return the HDFS NameNode URI."""
        return self._namenode_uri

    # ----------------------------------------------------------------
    # HDFS Directory Setup
    # ----------------------------------------------------------------

    def setup_hdfs_directories(self) -> None:
        """
        Create all configured HDFS directories.

        Reads paths from hadoop_config.yaml and ensures each exists.
        """
        self._logger.info("Setting up HDFS directory structure...")

        # Create base path
        self.create_directory(self._base_path)

        # Create all configured sub-paths
        for path_key, path_value in self._hdfs_paths.items():
            self.create_directory(path_value)
            self._logger.info(
                "HDFS directory ready: %s → %s", path_key, path_value
            )

        self._logger.info("HDFS directory structure setup complete.")

    # ----------------------------------------------------------------
    # Retry Logic
    # ----------------------------------------------------------------

    def _retry_operation(
        self, operation_name: str, func: callable, **kwargs: Any
    ) -> Any:
        """
        Execute an HDFS operation with retry logic.

        Args:
            operation_name: Human-readable name for logging.
            func: The function to execute.
            **kwargs: Arguments to pass to the function.

        Returns:
            The return value of the function.

        Raises:
            HDFSOperationError: If operation fails after all retries.
        """
        last_exception = None

        for attempt in range(1, self._max_retries + 1):
            try:
                return func(**kwargs)
            except HDFSOperationError:
                # Re-raise domain errors immediately (no retry)
                raise
            except Exception as e:
                last_exception = e
                self._logger.warning(
                    "HDFS operation '%s' failed (attempt %d/%d): %s",
                    operation_name,
                    attempt,
                    self._max_retries,
                    str(e),
                )
                if attempt < self._max_retries:
                    time.sleep(self._retry_delay)

        error_msg = (
            f"HDFS operation '{operation_name}' failed after "
            f"{self._max_retries} attempts. Last error: {last_exception}"
        )
        self._logger.error(error_msg)
        raise HDFSOperationError(error_msg)

    # ----------------------------------------------------------------
    # Context Manager
    # ----------------------------------------------------------------

    def __enter__(self) -> "HDFSClient":
        """Support usage as context manager."""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Disconnect on context manager exit."""
        self.disconnect()

    def __repr__(self) -> str:
        return (
            f"HDFSClient(namenode='{self._namenode_uri}', "
            f"base_path='{self._base_path}')"
        )
