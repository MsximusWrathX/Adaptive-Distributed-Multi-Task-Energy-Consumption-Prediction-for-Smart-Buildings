"""
Spark Session Manager Module
=============================

Singleton manager for Apache Spark sessions. Handles configuration,
initialization, and graceful shutdown.

Architectural Decisions:
    - Singleton Pattern: Ensures only one Spark context exists per JVM,
      preventing resource leaks and conflicts, particularly in cluster mode.
    - Adaptive Query Execution (AQE): Enabled to dynamically optimize shuffle
      partitions and join strategies during execution.
    - Timezone: Set to UTC to prevent implicit timezone conversions from
      corrupting timestamps.
"""

from typing import Any, Dict, Optional
from pyspark.sql import SparkSession

from src.logging.logger_factory import LoggerFactory


class SparkSessionManager:
    """
    Singleton manager for the SparkSession.

    Reads configuration from spark_config.yaml and sets up
    the Spark environment with optimized parameters.
    """

    _instance: Optional["SparkSessionManager"] = None
    _spark: Optional[SparkSession] = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(SparkSessionManager, cls).__new__(cls)
        return cls._instance

    def __init__(self, spark_config: Optional[Dict[str, Any]] = None):
        """
        Initialize the SparkSessionManager.
        
        Args:
            spark_config: The 'spark' section from the configuration.
                          Required on first initialization.
        """
        # Only initialize once
        if getattr(self, "_initialized", False):
            return

        self._logger = LoggerFactory.get_logger(self.__class__.__name__)
        
        if spark_config is None:
            raise ValueError("spark_config is required for first initialization")
            
        self._config = spark_config.get("spark", spark_config)
        self._initialized = True

    def get_session(self) -> SparkSession:
        """
        Get or create the SparkSession.

        Returns:
            The active SparkSession.
        """
        if self._spark is not None:
            return self._spark

        self._logger.info("Initializing SparkSession...")

        app_name = self._config.get("app_name", "AdaptiveEnergyPrediction")
        master = self._config.get("master", "local[*]")
        executor_memory = self._config.get("executor_memory", "4g")
        driver_memory = self._config.get("driver_memory", "2g")
        executor_cores = str(self._config.get("executor_cores", "2"))
        shuffle_partitions = str(self._config.get("shuffle_partitions", "200"))
        default_parallelism = str(self._config.get("default_parallelism", "8"))
        log_level = self._config.get("log_level", "WARN")

        builder = (
            SparkSession.builder.appName(app_name)
            .master(master)
            .config("spark.executor.memory", executor_memory)
            .config("spark.driver.memory", driver_memory)
            .config("spark.executor.cores", executor_cores)
            .config("spark.sql.shuffle.partitions", shuffle_partitions)
            .config("spark.default.parallelism", default_parallelism)
            # Enable Adaptive Query Execution for performance optimization
            .config("spark.sql.adaptive.enabled", "true")
            .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
            # Force UTC timezone for consistent timestamp processing
            .config("spark.sql.session.timeZone", "UTC")
            # Optimize joins
            .config("spark.sql.autoBroadcastJoinThreshold", "10485760") # 10MB
        )

        self._spark = builder.getOrCreate()
        self._spark.sparkContext.setLogLevel(log_level)

        self._logger.info(
            "SparkSession initialized: master=%s, app_name=%s", master, app_name
        )
        return self._spark

    def stop(self) -> None:
        """
        Gracefully stop the SparkSession.
        """
        if self._spark is not None:
            self._logger.info("Stopping SparkSession...")
            self._spark.stop()
            self._spark = None
            self._logger.info("SparkSession stopped.")
